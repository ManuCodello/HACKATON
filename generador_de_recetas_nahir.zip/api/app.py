from flask import Flask, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
import requests

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///recetas.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class Receta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre_receta = db.Column(db.String(200), unique=True, nullable=False)
    descripcion = db.Column(db.Text)
    ingredientes = db.Column(db.Text)
    pasos = db.Column(db.Text)
    tiempo = db.Column(db.String(50))
    categoria = db.Column(db.String(50))
    dieta = db.Column(db.String(100))
    porciones = db.Column(db.Integer)
    calorias = db.Column(db.Integer)
    proteina = db.Column(db.String(50))
    grasa = db.Column(db.String(50))
    carbohidratos = db.Column(db.String(50))
    
class Ingrediente(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100))
    cantidad = db.Column(db.Float)
    unidad = db.Column(db.String(50))
    almacenamiento = db.Column(db.String(50))  
    vencimiento = db.Column(db.String(50))


with app.app_context():
    db.create_all()

@app.route("/", methods=["GET", "POST"])
def home():
    recetas = Receta.query.all()
    ingredientes = Ingrediente.query.all()
    return render_template("inventario.html",recetas=recetas,ingredientes=ingredientes)


@app.route('/generar_receta', methods=['POST'])
def generar_receta():
    url = 'https://magicloops.dev/api/loop/3684ffb1-9eb8-4e88-983d-6a9995cddc93/run'
    payload = {}  

    response = requests.post(url, json=payload)

    if response.status_code != 200:
        return jsonify({"error": "No se pudo obtener la receta"}), 500

    data = response.json()

    nombre = data.get("nombre_receta")
    if not nombre:
        return jsonify({"error": "La receta no tiene nombre"}), 400

    existente = Receta.query.filter_by(nombre_receta=nombre).first()
    if existente:
        return jsonify({"mensaje": "La receta ya existe en la base de datos."}), 200

    nueva_receta = Receta(
        nombre_receta=nombre,
        descripcion=data.get("descripcion"),
        ingredientes=str(data.get("ingredientes")),
        pasos=str(data.get("pasos")),
        tiempo=data.get("tiempo"),
        categoria=data.get("categoria"),
        dieta=data.get("dieta"),
        porciones=data.get("porciones"),
        calorias=data.get("calorias"),
        proteina=data.get("proteina"),
        grasa=data.get("grasa"),
        carbohidratos=data.get("carbohidratos")
    )
    db.session.add(nueva_receta)
    db.session.commit()
    return jsonify({"mensaje": "Receta guardada correctamente", "receta": data}), 201

@app.route('/inventario', methods=['GET'])
def ver_inventario():
    recetas = Receta.query.all()
    resultado = []
    for r in recetas:
        resultado.append({
            "id": r.id,
            "nombre_receta": r.nombre_receta,
            "descripcion": r.descripcion,
            "ingredientes": r.ingredientes,
            "pasos": r.pasos,
            "tiempo": r.tiempo,
            "categoria": r.categoria,
            "dieta": r.dieta,
            "porciones": r.porciones,
            "calorias": r.calorias,
            "proteina": r.proteina,
            "grasa": r.grasa,
            "carbohidratos": r.carbohidratos
        })
    return jsonify(resultado), 200

@app.route('/ver_recetas')
def ver_recetas():
    return render_template("inventario.html")

if __name__ == '__main__':
    app.run(debug=True)
